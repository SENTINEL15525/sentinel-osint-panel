from fastapi import FastAPI

# Create app instance without complex parameters that might cause issues
app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "SENTINEL OSINT Panel is running"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}

@app.get("/api/ping")
def ping():
    return {"message": "pong"}

# For Vercel deployment
application = app
