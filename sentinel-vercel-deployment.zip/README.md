# SENTINEL OSINT Panel - Vercel Deployment Ready

This is a complete, ready-to-deploy package for your SENTINEL OSINT panel.

## Files Included:

1. **vercel_entrypoint.py** - FastAPI entrypoint for Vercel
2. **requirements-vercel.txt** - Dependencies for Vercel
3. **vercel.json** - Vercel configuration
4. **README.md** - Deployment instructions

## How to Deploy to Vercel:

### Step 1: Create a Git Repository
1. Create a new repository on GitHub/GitLab
2. Push these files to your repository

### Step 2: Deploy to Vercel
1. Go to https://vercel.com
2. Sign in or create an account
3. Import your Git repository
4. Vercel will automatically detect and deploy your app

### Step 3: Access on Mobile
1. Once deployed, you'll get a URL like `https://your-app.vercel.app`
2. Open this URL in your phone's browser
3. Your SENTINEL OSINT panel will be accessible on mobile

## Features:
- Responsive design for mobile devices
- Full OSINT panel functionality
- Database-ready (configure DATABASE_URL in Vercel settings)
- Zero downtime deployment
- Automatic scaling

## For Mobile Installation (Optional):
Add a PWA manifest to enable app-like experience on mobile devices.